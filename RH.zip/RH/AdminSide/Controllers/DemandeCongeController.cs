using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System;
using RessourceHumaine;

public class DemandeCongeController : Controller
{
     public IActionResult Index(IFormCollection form)
    {
        ViewBag.allEmployer = EmployerModel.getAll();
        return View();
    }

       public IActionResult Validation(IFormCollection form)
    {
        ViewBag.ListeDemandeConge = DemandeCongeModel.AllDemande(0);
        return View("Validation","DemandeConge");
    }
    
    public IActionResult PrevisionConge()
    {
        ViewBag.PrevisionConge = DemandeCongeModel.PrevisionConge(10);
        return View("PrevisionConge","DemandeConge");

    }

   [HttpPost]
    public IActionResult Insert(IFormCollection form)
    {
        var demande = new DemandeCongeModel
        {
            ID_Conge = "CG" + DemandeCongeModel.GetID(),
            Matricule = form["Matricule"].ToString(),
            DateDepart = DateTime.Parse(form["dateD"]),
            DateRetour = DateTime.Parse(form["dateR"]),
            ID_TypeConge = form["ID_TypeConge"].ToString(),
            Motif = form["Motif"].ToString(),
            Etat = 0
        };
        
        DemandeCongeModel.InsertDemandeConge(demande);
        return RedirectToAction("Validation", "DemandeConge");
        
    }

    public IActionResult Valider(string id){
        DemandeCongeModel.UpdateEtatByCongeID(id,10);
        return RedirectToAction("Validation", "DemandeConge");
    }

    public IActionResult Refuser(string id){
        DemandeCongeModel.UpdateEtatByCongeID(id,5);
        return RedirectToAction("Validation", "DemandeConge");
    }
}
