using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System;
using RessourceHumaine;

public class ValidationCongeController : Controller
{
     public IActionResult Index(IFormCollection form)
    {
        return View();
    }


    public IActionResult Valider(string IDConge){
        DemandeCongeModel.UpdateEtatByCongeID(IDConge, 10);
        return RedirectToAction("Index", "CongeEmployer");
    }

    public IActionResult Refuser(string IDConge){
        DemandeCongeModel.UpdateEtatByCongeID(IDConge, 10);
        return RedirectToAction("Index", "CongeEmployer");
    }

}
