using Npgsql;
using System;

namespace RessourceHumaine
{
    public class FicheDePaieAjaxModel
    {
        public string matricule { get; set; }
        public string date_debut { get; set; }
    }
}
