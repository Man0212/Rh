using Npgsql;
using System;

namespace RessourceHumaine
{
    public class ValidationAjaxModel
    {
        public string tri { get; set; }
        public string sort { get; set; }
        public string genre { get; set; }      
        public string searchval { get; set; }      
    }
}
